require('dotenv').config()
require('./utils')
require('./bot')
require('./statTracking')